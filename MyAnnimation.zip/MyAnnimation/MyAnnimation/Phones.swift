//
//  Phones.swift
//  MyAnnimation
//
//  Created by mac on 11/17/20.
//

import Foundation


class Phones {
    var typePhone : String?
    var pricePhone : String?
    
    init(_ typePhone: String, _ pricePhone: String) {
        self.pricePhone = pricePhone
        self.typePhone = typePhone
    }
}
