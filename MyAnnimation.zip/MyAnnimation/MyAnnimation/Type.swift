//
//  Type.swift
//  MyAnnimation
//
//  Created by mac on 11/19/20.
//

import Foundation


class Type{
    
    var program : String
    var pixel : String
    
    init(_ program: String, _ pixel: String){
        self.pixel = pixel
        self.program = program
    }
}
